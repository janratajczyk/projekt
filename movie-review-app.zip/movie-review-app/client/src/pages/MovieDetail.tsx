import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function MovieDetail() {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    axios.get(\`https://api.themoviedb.org/3/movie/\${id}?api_key=YOUR_API_KEY\`)
      .then(res => setMovie(res.data));
    axios.get(\`/api/reviews/\${id}\`).then(res => setReviews(res.data));
  }, [id]);

  return movie && (
    <div className="p-4">
      <h1 className="text-2xl font-bold">{movie.title}</h1>
      <p>{movie.overview}</p>
      <div>
        <h2 className="text-xl mt-4">Recenzje:</h2>
        {reviews.map(r => (
          <div key={r._id} className="border-t mt-2 pt-2">
            <p><strong>{r.userId.username}</strong>: {r.rating}/10</p>
            <p>{r.comment}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
