import mongoose from 'mongoose';

const reviewSchema = new mongoose.Schema({
  movieId: { type: String, required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  rating: { type: Number, required: true },
  comment: { type: String },
});

export default mongoose.model('Review', reviewSchema);
