import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/api/register', { username, email, password });
      navigate('/login');
    } catch (err) {
      alert('Rejestracja nie powiodła się');
    }
  };

  return (
    <form onSubmit={handleRegister} className="p-4 max-w-sm mx-auto">
      <h2 className="text-xl mb-4">Zarejestruj się</h2>
      <input type="text" placeholder="Nazwa użytkownika" value={username} onChange={(e) => setUsername(e.target.value)} className="block w-full mb-2" />
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="block w-full mb-2" />
      <input type="password" placeholder="Hasło" value={password} onChange={(e) => setPassword(e.target.value)} className="block w-full mb-2" />
      <button type="submit" className="bg-green-500 text-white px-4 py-2">Zarejestruj</button>
    </form>
  );
}
