import Review from '../models/Review';

export const addReview = async (req, res) => {
  const { movieId, rating, comment } = req.body;
  const review = new Review({ movieId, userId: req.user.id, rating, comment });
  await review.save();
  res.status(201).json(review);
};

export const getReviews = async (req, res) => {
  const { movieId } = req.params;
  const reviews = await Review.find({ movieId }).populate('userId', 'username');
  res.json(reviews);
};
